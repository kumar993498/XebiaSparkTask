import pyspark
from pyspark import SparkConf, SparkContext
import collections
from pyspark.sql import SQLContext
from pyspark.sql import DataFrame
from pyspark.sql import Column
from pyspark.sql import Row
from pyspark.sql import HiveContext
from pyspark.sql import GroupedData
from pyspark.sql import DataFrameNaFunctions
from pyspark.sql import DataFrameStatFunctions
from pyspark.sql import functions
from pyspark.sql import types
from pyspark.sql import Window
from pyspark.sql.types import *
from pyspark import sql

def main():
        conf = SparkConf().setMaster("local").setAppName("XebiaAnalysis")
        sc = SparkContext(conf = conf)
        sqlContext = sql.SQLContext(sc)
        lines = sc.textFile("/opt/xebia/aadhaar_data.csv")
        parts = lines.map(lambda x:x.split(","))
        Aadhaar = parts.map(lambda p: (p[0], p[1],p[2],p[3],p[4],p[5],p[6],p[7],p[8],p[9],p[10],p[11],p[12].strip()))
        schemaString = "date registrar private_agency state district sub_district pincode gender age aadhaar_generated rejected mobile_number email_id"
        fields = [StructField(field_name, StringType(), True) for field_name in schemaString.split()]
        schema = StructType(fields)
        schemaPeople = sqlContext.createDataFrame(Aadhaar, schema)
        schemaPeople.registerTempTable("Aadhaar")
        results = sqlContext.sql("SELECT * FROM Aadhaar").show()
if __name__ == '__main__':
    main()